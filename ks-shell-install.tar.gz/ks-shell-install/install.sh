#!/usr/bin/env bash
#
set -o errexit
set -o pipefail
#
# description: Sample to install APPs  
# using KickStart and shell script
# version: 0.1
# author: Thiago Fonseca Born da Silva
# e-mail: thiagofborn@gmail.com
#-------------------------------------------------

echo "Installing VI improved"
yum -y install screen vim

